/* E-DESIGN - Application professionnelle locale */
(() => {
"use strict";
const KEY="EDESIGN_APP_V1", REM="EDESIGN_REMINDER_HISTORY_V1";
let db=load(), deferredInstall=null;
function load(){try{return JSON.parse(localStorage.getItem(KEY))||{clients:[],orders:[],payments:[]}}catch{return {clients:[],orders:[],payments:[]}}}
function save(){localStorage.setItem(KEY,JSON.stringify(db));render()}
function id(prefix){return prefix+"-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,5).toUpperCase()}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function money(n){return "$"+(Number(n)||0).toFixed(2)}
function toast(s){const t=document.getElementById("toast");t.textContent=s;t.style.display="block";setTimeout(()=>t.style.display="none",3000)}
function showView(v){document.querySelectorAll(".view").forEach(x=>x.classList.toggle("active",x.id===v));document.querySelectorAll(".nav button").forEach(x=>x.classList.toggle("active",x.dataset.view===v));render()}
window.showView=showView;
document.querySelectorAll(".nav button").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
function modal(title,body){document.getElementById("modalTitle").textContent=title;document.getElementById("modalBody").innerHTML=body;document.getElementById("modal").classList.add("show")}
function closeModal(){document.getElementById("modal").classList.remove("show")}
window.closeModal=closeModal;
function field(label,name,placeholder="",type="text",required=false,value=""){return `<div class="field"><label>${label}${required?" *":""}</label><input name="${name}" type="${type}" placeholder="${placeholder}" value="${esc(value)}" ${required?"required":""}></div>`}
function getForm(){return document.querySelector("#modalBody form")}
function openClientForm(clientId=null){
 const c=db.clients.find(x=>x.id===clientId)||{};
 modal(clientId?"Modifier le client":"Nouveau client",`<form id="clientForm"><div class="formgrid">
 ${field("Nom","nom","Nom de famille","text",true,c.nom)}
 ${field("Postnom","postnom","Postnom","text",true,c.postnom)}
 ${field("Adresse physique","adresse","Ville, quartier, avenue")}
 ${field("Téléphone / WhatsApp","telephone","+243…","tel",true,c.telephone)}
 ${field("Profession","profession","Profession")}
 ${field("Adresse e-mail","email","nom@exemple.com","email",false,c.email)}
 </div><p class="smallprint">Les champs marqués * sont obligatoires. Le code client est généré automatiquement.</p><div class="form-actions"><button type="button" class="btn soft" onclick="closeModal()">Annuler</button><button class="btn primary">Enregistrer</button></div></form>`);
 getForm().onsubmit=e=>{e.preventDefault();const f=new FormData(e.target),v=Object.fromEntries(f.entries());
 if(!v.nom.trim()||!v.postnom.trim()||!v.telephone.trim()){toast("Veuillez remplir les champs obligatoires.");return}
 if(!/^[+0-9][0-9\s().-]{6,20}$/.test(v.telephone.trim())){toast("Numéro de téléphone invalide.");return}
 if(v.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)){toast("Adresse e-mail invalide.");return}
 const duplicate=db.clients.find(x=>x.telephone.replace(/\D/g,"")===v.telephone.replace(/\D/g,"")&&x.id!==clientId);
 if(duplicate){toast("Ce numéro existe déjà dans le répertoire.");return}
 if(clientId)Object.assign(c,v);else db.clients.push({id:id("ED"),code:"ED-"+String(db.clients.length+1).padStart(4,"0"),createdAt:new Date().toISOString(),...v});
 save();closeModal();toast("Fiche client enregistrée.");
 };
}
window.openClientForm=openClientForm;
function openOrderForm(orderId=null){
 const o=db.orders.find(x=>x.id===orderId)||{};
 const options=db.clients.map(c=>`<option value="${c.id}" ${o.clientId===c.id?"selected":""}>${esc(c.nom+" "+c.postnom)} — ${esc(c.code)}</option>`).join("");
 if(!db.clients.length){toast("Ajoutez d'abord un client.");showView("clients");return}
 modal(orderId?"Modifier la commande":"Nouvelle commande",`<form id="orderForm"><div class="formgrid">
 <div class="field"><label>Client *</label><select name="clientId" required><option value="">Sélectionner un client</option>${options}</select></div>
 ${field("Objet / service","description","Ex. Conception flyer","text",true,o.description)}
 ${field("Montant total ($)","total","0.00","number",true,o.total??"")}
 ${field("Date limite de paiement","due","AAAA-MM-JJ","date",true,o.due??"")}
 ${field("Notes","notes","Détails complémentaires")}
 </div><p class="smallprint">Un paiement initial de zéro sera enregistré. Ajoutez les versements après la création.</p><div class="form-actions"><button type="button" class="btn soft" onclick="closeModal()">Annuler</button><button class="btn primary">Créer la commande</button></div></form>`);
 getForm().onsubmit=e=>{e.preventDefault();const f=new FormData(e.target),v=Object.fromEntries(f.entries()),total=Number(v.total);
 if(!v.clientId||!v.description.trim()||!v.due||!Number.isFinite(total)||total<=0){toast("Vérifiez les informations obligatoires et le montant.");return}
 if(orderId){Object.assign(o,{...v,total});}else db.orders.unshift({id:id("CMD"),...v,total,paid:0,status:"En cours",createdAt:new Date().toISOString()});
 save();closeModal();toast("Commande enregistrée.");
 };
}
window.openOrderForm=openOrderForm;
function clientFor(o){return db.clients.find(c=>c.id===o.clientId)||{}}
function paid(o){return Number(o.paid)||0}
function balance(o){return Math.max(0,Number(o.total)-paid(o))}
function dateState(o){if(balance(o)<=0)return "Soldée";if(!o.due)return "Échéance inconnue";const d=new Date(o.due+"T23:59:59");return d<new Date()?"En retard":(new Date(o.due+"T00:00:00")-new Date()<=86400000?"Échéance proche":"À payer")}
function badge(s){let cl=s==="Soldée"?"green":s==="En retard"?"red":s==="Échéance proche"?"orange":"";return `<span class="pill ${cl}">${esc(s)}</span>`}
function orderCard(o){const c=clientFor(o),b=balance(o),st=dateState(o);return `<div class="card"><div class="row"><div><div class="name">${esc(c.nom||"Client")} ${esc(c.postnom||"")}</div><div class="muted">${esc(o.description)} · ${esc(o.id)}</div></div>${badge(st)}</div><div class="row" style="margin-top:12px"><div><div class="muted">Total · Payé</div><b>${money(o.total)} · ${money(paid(o))}</b></div><div style="text-align:right"><div class="muted">Solde restant</div><div class="amount ${b>0?"dangertext":""}">${money(b)}</div></div></div><div class="muted" style="margin-top:7px">Échéance : ${esc(o.due||"Non définie")}</div><div class="actions">${b>0?`<button class="btn success" onclick="addPayment('${o.id}')">＋ Paiement</button><button class="btn danger" onclick="callClient('${o.id}')">☎ Appeler</button>`:`<button class="btn success" onclick="thankClient('${o.id}')">✉ Remercier</button>`}<button class="btn soft" onclick="editOrder('${o.id}')">Modifier</button></div></div>`}
window.editOrder=id=>openOrderForm(id);
function addPayment(oid){const o=db.orders.find(x=>x.id===oid);if(!o)return;const b=balance(o);modal("Enregistrer un paiement",`<form id="payForm"><p>Solde restant : <b>${money(b)}</b></p><div class="field"><label>Montant reçu ($) *</label><input name="amount" type="number" min="0.01" max="${b}" step="0.01" required></div><div class="field" style="margin-top:10px"><label>Mode de paiement</label><select name="method"><option>Espèces</option><option>Mobile Money</option><option>Virement</option><option>Autre</option></select></div><div class="form-actions"><button type="button" class="btn soft" onclick="closeModal()">Annuler</button><button class="btn primary">Confirmer le paiement</button></div></form>`);
 getForm().onsubmit=e=>{e.preventDefault();const f=new FormData(e.target),amount=Number(f.get("amount"));if(!Number.isFinite(amount)||amount<=0||amount>b+0.000001){toast("Montant invalide ou supérieur au solde.");return}
 o.paid=Math.min(Number(o.total),paid(o)+amount);db.payments.unshift({id:id("PAY"),orderId:oid,amount,method:f.get("method"),date:new Date().toISOString()});save();closeModal();toast("Paiement enregistré.");if(balance(o)===0){setTimeout(()=>thankClient(oid),250)}
 };
}
window.addPayment=addPayment;
function callClient(oid){const o=db.orders.find(x=>x.id===oid),c=o&&clientFor(o);if(!o||balance(o)<=0){toast("Aucune dette à recouvrer.");return}if(!c.telephone){toast("Aucun téléphone renseigné pour ce client.");return}
 if(confirm(`CONFIRMATION D'APPEL\n\n${c.nom} ${c.postnom}\n${c.telephone}\nSolde : ${money(balance(o))}\n\nOuvrir le composeur téléphonique ?`)){const a=document.createElement("a");a.href="tel:"+c.telephone.replace(/[^\d+]/g,"");document.body.appendChild(a);a.click();a.remove();db.payments.unshift({id:id("ACT"),orderId:oid,amount:0,method:"Tentative d'appel",date:new Date().toISOString()});localStorage.setItem(KEY,JSON.stringify(db))}
}
window.callClient=callClient;
function thankClient(oid){const o=db.orders.find(x=>x.id===oid),c=o&&clientFor(o);if(!o||balance(o)>0){toast("Le solde doit être nul avant le remerciement.");return}
 const msg=`Bonjour ${c.nom||""} ${c.postnom||""},\n\nNous vous remercions sincèrement d'avoir entièrement réglé votre dette auprès de E-DESIGN. Votre compte est désormais soldé. Merci pour votre confiance et votre collaboration.\n\nAu plaisir de vous servir à nouveau !\nE-DESIGN — Professionnalisme, créativité et confiance.`;
 const phone=(c.telephone||"").replace(/[^\d+]/g,"");
 modal("Dette soldée — Remerciements",`<div class="alert" style="background:#eaf7f0;color:#16865b">Paiement intégral confirmé. Le compte de ce client est soldé.</div><div class="field"><label>Message</label><textarea id="thankText" rows="7">${esc(msg)}</textarea></div><div class="actions"><button class="btn success" onclick="sendWhatsApp('${esc(phone)}')">Ouvrir WhatsApp</button><button class="btn soft" onclick="copyThanks()">Copier le message</button></div><p class="smallprint">Le message est préparé. Vérifiez-le puis confirmez son envoi dans WhatsApp.</p>`);
}
window.thankClient=thankClient;
window.sendWhatsApp=phone=>{const msg=document.getElementById("thankText").value;window.open("https://wa.me/"+phone.replace(/\D/g,"")+"?text="+encodeURIComponent(msg),"_blank")};
window.copyThanks=()=>{navigator.clipboard?.writeText(document.getElementById("thankText").value).then(()=>toast("Message copié.")).catch(()=>toast("Copie non disponible sur cet appareil."))};
function render(){
 document.getElementById("statClients").textContent=db.clients.length;
 document.getElementById("statOrders").textContent=db.orders.length;
 document.getElementById("statDebts").textContent=money(db.orders.reduce((s,o)=>s+balance(o),0));
 document.getElementById("statLate").textContent=db.orders.filter(o=>dateState(o)==="En retard").length;
 const debts=db.orders.filter(o=>balance(o)>0);
 document.getElementById("dashboardDebts").innerHTML=debts.length?debts.slice(0,3).map(orderCard).join(""):`<div class="empty">Aucune dette en cours. Excellent travail !</div>`;
 document.getElementById("dashboardOrders").innerHTML=db.orders.length?db.orders.slice(0,3).map(orderCard).join(""):`<div class="empty">Aucune commande enregistrée.</div>`;
 const cs=document.getElementById("clientSearch")?.value.toLowerCase()||"";
 document.getElementById("clientList").innerHTML=db.clients.filter(c=>(c.nom+" "+c.postnom+" "+c.code+" "+c.telephone).toLowerCase().includes(cs)).map(c=>`<div class="card"><div class="row"><div><div class="name">${esc(c.nom)} ${esc(c.postnom)}</div><div class="muted">${esc(c.code)} · ${esc(c.profession||"Profession non renseignée")}</div></div><button class="btn soft" onclick="editClient('${c.id}')">Modifier</button></div><div class="muted" style="margin-top:9px">☎ ${esc(c.telephone)} · ✉ ${esc(c.email||"Non renseigné")}</div><div class="muted">${esc(c.adresse||"Adresse non renseignée")}</div></div>`).join("")||`<div class="empty">Aucun client. Ajoutez votre premier client.</div>`;
 const os=document.getElementById("orderSearch")?.value.toLowerCase()||"";
 document.getElementById("orderList").innerHTML=db.orders.filter(o=>(o.description+" "+(clientFor(o).nom||"")).toLowerCase().includes(os)).map(orderCard).join("")||`<div class="empty">Aucune commande enregistrée.</div>`;
 document.getElementById("debtList").innerHTML=debts.sort((a,b)=>String(a.due).localeCompare(String(b.due))).map(orderCard).join("")||`<div class="empty">Aucun client ne doit actuellement de paiement.</div>`;
}
window.editClient=id=>openClientForm(id);
document.getElementById("clientSearch").addEventListener("input",render);
document.getElementById("orderSearch").addEventListener("input",render);
function checkReminders(manual=false){
 let hist={};try{hist=JSON.parse(localStorage.getItem(REM))||{}}catch{}
 const today=new Date().toISOString().slice(0,10);let alerts=[];
 db.orders.forEach(o=>{if(balance(o)<=0||!o.due)return;const due=new Date(o.due+"T23:59:59"),diff=due-new Date(),c=clientFor(o),name=(c.nom||"Client")+" "+(c.postnom||"");let type=diff<0?"retard":diff<=86400000?"avant":null;if(!type)return;const k=o.id+"_"+type;if(hist[k]===today)return;hist[k]=today;alerts.push(`${name} : ${type==="retard"?"paiement en retard":"échéance dans moins de 24 heures"}. Solde ${money(balance(o))}.`);});
 localStorage.setItem(REM,JSON.stringify(hist));
 if(alerts.length){alerts.forEach(x=>notify("E-DESIGN — Rappel",x));}
 else if(manual)toast("Vérification terminée : aucun nouveau rappel.");
}
function notify(title,body){if("Notification"in window&&Notification.permission==="granted"){new Notification(title,{body})}else{toast(title+" — "+body)}}
async function enableNotifications(){if(!("Notification"in window)){toast("Notifications non prises en charge par ce navigateur.");return}const p=await Notification.requestPermission();toast(p==="granted"?"Notifications autorisées.":"Autorisation refusée.");}
window.enableNotifications=enableNotifications;window.checkReminders=checkReminders;
document.getElementById("notifyBtn").onclick=enableNotifications;
function exportData(){const blob=new Blob([JSON.stringify({db,exportedAt:new Date().toISOString()},null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="E-DESIGN-sauvegarde.json";a.click();URL.revokeObjectURL(url);toast("Sauvegarde téléchargée.");}
window.exportData=exportData;
function importData(){const f=document.getElementById("importFile").files[0];if(!f){toast("Choisissez un fichier de sauvegarde.");return}const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result),d=x.db||x;if(!Array.isArray(d.clients)||!Array.isArray(d.orders))throw Error();if(!confirm("La restauration remplacera les données présentes sur cet appareil. Continuer ?"))return;db={clients:d.clients,orders:d.orders,payments:d.payments||[]};save();toast("Sauvegarde restaurée.")}catch{toast("Fichier de sauvegarde invalide.")}};r.readAsText(f)}
window.importData=importData;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;document.getElementById("installBtn").hidden=false});
document.getElementById("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null}else toast("Utilisez le menu du navigateur puis Ajouter à l'écran d'accueil.")};
if("serviceWorker"in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
document.getElementById("greeting").textContent="Bonjour 👋";
render();checkReminders();setInterval(()=>{if(!document.hidden)checkReminders()},60000);
})();